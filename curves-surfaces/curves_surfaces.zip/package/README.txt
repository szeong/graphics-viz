Name: Ong Sze Swee
ID: 1000969

No collaboration with anyone in the class as of last week and this week.
The OpenGL Programming Guide v3.0 was used a reference material for some OpenGL functions.

-- INSTRUCTIONS --
1) Launch 'one.exe' | USAGE: $ one.exe FILEPATH

-- WORKING FUNCTIONS --
1) Bezier curve drawing implemented

-- PARTIALLY WORKING FUNCTIONS --
1) B-spline curve drawing code implemented through bezier curve basis transformation.
   However, results on the screen are not at all what is expected of a B-spline.

-- NOT IMPLEMENTED --
1) No surfaces implemented due to time constraint.
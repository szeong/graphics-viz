Name: Ong Sze Swee
ID: 1000969

No collaboration with anyone in the class as of last week and this week.
Plenty of stackoverflow was used to learn c++.
The OpenGL Programming Guide v3.0 was used a reference material for some OpenGL functions.

-- INSTRUCTIONS --
1) Launch 'a0.exe'. No standard input necessary.
2) The program will prompt for the filename of the object to render. Ensure the .obj files are in the same directory as the executable.
3) If the type matches, the program will run and render the object in a separate window.

-- WORKING FUNCTIONS --
1) Colour change implemented. Press 'c' to flip between pre-assigned colours.
2) Light position implemented along the X-Y plane. Use the arrow keys to move the light.

-- PARTIALLY WORKING FUNCTIONS --
1) Extra credit: Rotation toggle working somewhat. Press 'r' to toggle rotation.
   However, once disabled, the object will return to the initial render position, not stop in its tracks.
   I believe, given more time, this bug can be fixed, as all it requires is a simple rotation matrix multiplication to the vertices.
   The modified vertices will then display the new location of the object.
   Also, I noticed that the rotation will speed up with successive rotation toggles, which I suspect is due to the repeat declaration of the glutTimerFunc again that causes the rotation angles to 'pile up' and speed the animation.